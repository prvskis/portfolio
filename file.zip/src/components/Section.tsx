import clsx from "clsx";
import type { PropsWithChildren } from "react";

type Props = PropsWithChildren<{
  id: string;
  className?: string;
  feather?: boolean;
}>;

export default function Section({
  id,
  className,
  feather = true,
  children,
}: Props) {
  return (
    <section
      id={id}
      className={clsx(
        "relative min-h-screen scroll-mt-24 py-0",
        feather && "feather",
        className
      )}
    >
      <div className="container-x relative z-10">{children}</div>
    </section>
  );
}